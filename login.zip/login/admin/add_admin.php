<?php
if (isset($_POST['save_admin'])) {
    // Retrieve and sanitize user input
    $User_Name = $_POST['User_Name'];
    $Password = $_POST['Password'];
    $First_Name = $_POST['First_Name'];
    $Middle_Name = $_POST['Middle_Name'];
    $Last_Name = $_POST['Last_Name'];

    // Create a connection to the database
    $conn = new mysqli("localhost", "root", "", "receivables_system");

    // Check for a connection error
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // Prepare a statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM `user_` WHERE `User_Name` = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters and execute the statement
    $stmt->bind_param("s", $User_Name);
    $stmt->execute();
    $result = $stmt->get_result();
    $c1 = $result->num_rows;

    if ($c1 > 0) {
        echo "<script>alert('Username already taken');</script>";
    } else {
        // Prepare an INSERT statement
        $stmt = $conn->prepare("INSERT INTO `user_` (`User_Name`, `Password`, `First_Name`, `Middle_Name`, `Last_Name`) VALUES (?, ?, ?, ?, ?)");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        // Bind parameters and execute the INSERT statement
        $stmt->bind_param("sssss", $User_Name, $Password, $First_Name, $Middle_Name, $Last_Name);
        $stmt->execute();

        echo "<script>location.replace('admin.php');</script>";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>