<?php
if (isset($_POST['add_employee'])) {
    // Retrieve and sanitize user input
    $Last_Name = $_POST['Last_Name'];
    $First_Name = $_POST['First_Name'];
    $Middle_Name = $_POST['Middle_Name'];
    $Position_ = $_POST['Position_'];
    $Office_ = $_POST['Office_'];
    $Contact_No = $_POST['Contact_No'];
    $Email_Ad = $_POST['Email_Ad'];
    $Picture_ = $_POST['Picture_'];

    // Create a connection to the database
    $conn = new mysqli("localhost", "root", "", "receivables_system");

    // Check for a connection error
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare a statement to prevent SQL injection
    // If you want to check if an employee with the same email already exists, use Email_Ad as identifier
    $stmt = $conn->prepare("SELECT * FROM `employees_` WHERE `Emp_ID` = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters and execute the statement
    $stmt->bind_param("s", $Email_Ad); // Changed to Email_Ad for checking uniqueness
    $stmt->execute();
    $result = $stmt->get_result();
    $c1 = $result->num_rows;

    if ($c1 > 0) {
        echo "<script>alert('Email address already taken');</script>";
    } else {
        // Prepare an INSERT statement
        $stmt = $conn->prepare("INSERT INTO `employees_` (`Last_Name`, `First_Name`, `Middle_Name`, `Position_`, `Office_`, `Contact_No`, `Email_Ad`, `Picture_`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        // Bind parameters and execute the INSERT statement
        $stmt->bind_param("sssssssb", $Last_Name, $First_Name, $Middle_Name, $Position_, $Office_, $Contact_No, $Email_Ad, $Picture_);
        $stmt->execute();

        // Use header for redirection
        echo "<script>location.replace('Employee.php');</script>";
        
    } 

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>