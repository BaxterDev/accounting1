<?php
if (isset($_POST['save_user'])) {
    // Retrieve form data
    $User_Name = $_POST['User_Name'];
    $Password = $_POST['Password'];
    $First_Name = $_POST['First_Name'];
    $Middle_Name = $_POST['Middle_Name'];
    $Last_Name = $_POST['Last_Name'];
    $Section_ = $_POST['Section_'];

    // Database connection
    $conn = new mysqli("localhost", "root", "", "receivables_system");

    // Check for connection errors
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute the SELECT statement
    $stmt = $conn->prepare("SELECT * FROM `user_ca` WHERE `User_Name` = ?");
    $stmt->bind_param("s", $User_Name);
    $stmt->execute();
    $result = $stmt->get_result();
    
    // Check if user already exists
    if ($result->num_rows > 0) {
        echo "<script>alert('Username already taken')</script>";
    } else {
        // Prepare and execute the INSERT statement
        $stmt = $conn->prepare("INSERT INTO `user_ca` (`User_Name`, `Password`, `First_Name`, `Middle_Name`, `Last_Name`, `Section_`) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $User_Name, $Password, $First_Name, $Middle_Name, $Last_Name, $Section_);
        
        if ($stmt->execute()) {
            echo "<script>location.replace('user.php');</script>";
        } else {
            echo "<script>alert('Error: Could not save user.')</script>";
        }
    }

    // Close the statements and connection
    $stmt->close();
    $conn->close();
}
?>