<?php
	$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
	$conn->query("DELETE FROM `user_` WHERE `User_Name` = '$_GET[id]'") or die(mysqli_error());
	echo("<script> location.replace('admin.php');</script>");
