<?php
	$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
	$conn->query("DELETE FROM `employees_` WHERE `Emp_ID` = '$_GET[id]'") or die(mysqli_error());
	echo("<script> location.replace('Employee.php');</script>");
