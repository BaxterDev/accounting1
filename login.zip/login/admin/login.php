<?php
session_start();

if (isset($_POST['login'])) {
    $User_Name = $_POST['User_Name'];
    $Password = $_POST['Password'];

    // Create connection
    $conn = new mysqli("localhost", "root", "", "receivables_system");

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare statement
    $stmt = $conn->prepare("SELECT * FROM `user_` WHERE `User_Name` = ? AND `Password` = ?");
    $stmt->bind_param("ss", $User_Name, $Password);
    
    // Execute and fetch result
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch user data
        $fetch = $result->fetch_assoc();
        
        // Store session data
        $_SESSION['Series_'] = $fetch['Series_'];

        // Redirect to home.php
        header("Location: home.php");
        exit();
    } else {
        // Invalid username or password
        echo "<script>alert('Invalid username or password'); window.location = 'index.php';</script>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>