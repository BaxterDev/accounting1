<!DOCTYPE html>
<?php
	require_once'logincheck.php';
	$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
	$query = $conn->query("SELECT * FROM `user_ca` WHERE `Series_` = '$_SESSION[Series_]'") or die(mysqli_error());
	$fetch = $query->fetch_array();
?>
<html lang = "en">
	<head>	
		<title>Health Center Patient Record Management System</title>
		<meta charset = "UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "images/logo.png" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
	</head>
	<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/logo.png" style = "float:left;" height = "55px" /><label class = "navbar-brand">Office of the Municipal Accountant - Maconacon</label>
		<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php echo $fetch['First_Name']." ".$fetch['Last_Name'] ?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><span class = "glyphicon glyphicon-log-out"></span> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
	<br />
	<br />
	<br />
	<div class = "well">
		<div class = "panel panel-warning">
			<div class = "panel-heading">
				<center><label>Cash Advance - Local Travel</label></center>
			</div>
		</div>
		<a href = "CA_Approver.php" id = "d_record" style = "float:right; margin-right:10px;" href = "" class = "btn btn-success"><span class = "glyphicon glyphicon-log-out"></span> Back</a>
		<a href = "Cash_Advance.php" id = "d_record" style = "float:right; margin-right:10px;" href = "" class = "btn btn-success"><span class = "glyphicon glyphicon-print"></span> Print</a>
		<a href = "Cash_Advance.php" id = "d_record" style = "float:right; margin-right:10px;" href = "" class = "btn btn-success"><span class = "glyphicon glyphicon-book"></span> Refresh</a>
		<br />
		<br />
		<div class = "panel panel-primary">
			<div class = "panel-heading">
				<h4>Outstanding Cash Advance</h4>
			</div>
		</div>
		<br />
		<table id = "table" class = "display" cellspacing = "0" >
			<thead>
				<tr>
					<th>Trans No</th>
					<th>Trans ID</th>
					<th>Trans Date</th>
					<th>Emp ID</th>
					<th>Employee Name</th>
					<th>Purpose</th>
					<th>Destination</th>
					<th>Check No</th>
					<th>Amount</th>
					<th><center>Action</center></th>
				</tr>
			</thead>
			<tbody>
			<?php 
				$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `cash_advance` WHERE `Status_` = 'Pending' ORDER BY `Trans_No` ASC") or die(mysqli_error($conn));
				while($f = $q->fetch_array()){
			?>
				<tr>
					<td><?php echo $f['Trans_No']?></td>
					<td><?php echo $f['Trans_ID']?></td>
					<td><?php echo $f['Trans_Date']?></td>
					<td><?php echo $f['Emp_ID']?></td>
					<td><?php echo $f['First_Name']." ".$f['Last_Name'] ?></td>
					<td><?php echo $f['Purpose_']?></td>
					<td><?php echo $f['Destination_']?></td>
					<td><?php echo $f['Check_No']?></td>
					<td><?php echo number_format($f['Amount_']); ?></td>
					<td>
						<center>
							<a href = "view_ca.php?Trans_No=<?php echo $f['Trans_No']?>"class = "btn btn-sm btn-info"><span class = "glyphicon glyphicon-search"></span>View</a>
							<a href = "Approve_CA.php?Trans_No=<?php echo $f['Trans_No']?>"class = "btn btn-sm btn-info"><span class = "glyphicon glyphicon-search"></span>Approve</a>
						</center>
					</td>
				</tr>
			<?php
				}
					$conn->close();
			?>	
			</tbody>
		</table>



		
	</div>
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright: Receivables Management System Version 1.0 </label>
	</div>
	</body>
		<?php require "script.php" ?>
</html>