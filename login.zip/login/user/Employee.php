<!DOCTYPE html>
<?php
	require_once 'logincheck.php';
?>
<html lang = "eng">
	<head>
		<title>Barangay Fely Health Station Records System</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "../images/logo.png" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "../images/Logo.jpg" style = "float:left;" height = "55px" /><label class = "navbar-brand">Barangay Fely Health Center Records Management System</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `user_ca` WHERE `Series_` = '$_SESSION[Series_]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['First_Name']." ".$f['Last_Name'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
	<div id = "sidebar">
			<ul id = "menu" class = "nav menu">
				<li><a href = "home.php"><i class = "glyphicon glyphicon-home"></i> Dashboard</a></li>
				<li><a href = ""><i class = "glyphicon glyphicon-cog"></i> Accounts</a>
					<ul>
						<li><a href = "admin.php"><i class = "glyphicon glyphicon-cog"></i> Administrator</a></li>
						<li><a href = "user.php"><i class = "glyphicon glyphicon-cog"></i> User</a></li>
					</ul>
				</li>
				<li><li><a href = "patient.php"><i class = "glyphicon glyphicon-user"></i> Patient</a></li></li>
				<li><a href = ""><i class = "glyphicon glyphicon-folder-close"></i> Sections</a>
					<ul>
						<li><a href = "fecalysis.php"><i class = "glyphicon glyphicon-folder-open"></i> Fecalysis</a></li>
						<li><a href = "maternity.php"><i class = "glyphicon glyphicon-folder-open"></i> Maternity</a></li>
						<li><a href = "hematology.php"><i class = "glyphicon glyphicon-folder-open"></i> Hematology</a></li>
						<li><a href = "dental.php"><i class = "glyphicon glyphicon-folder-open"></i> Dental</a></li>
						<li><a href = "xray.php"><i class = "glyphicon glyphicon-folder-open"></i> Xray</a></li>
						<li><a href = "rehabilitation.php"><i class = "glyphicon glyphicon-folder-open"></i> Rehabilitation</a></li>
						<li><a href = "sputum.php"><i class = "glyphicon glyphicon-folder-open"></i> Sputum</a></li>
						<li><a href = "urinalysis.php"><i class = "glyphicon glyphicon-folder-open"></i> Urinalysis</a></li>
					</ul>
				</li>
			</ul>
	</div>
	<div id = "content">
		<br />
		<br />
		<br />
		<div id = "add" class = "panel panel-success">	
			<div class = "panel-heading">EMPLOYEE
				<label>ADD </label>
				<button id = "hide" class = "btn btn-sm btn-danger" style = "float:right; margin-top:-5px;"><span class = "glyphicon glyphicon-remove"></span> CLOSE</button>
			</div>
			<div class = "panel-body">
				<form id = "form_admin" method = "POST" enctype = "multi-part/form-data" >
					<div class = "panel panel-default" style = "width:60%; margin:auto;">
					<div class = "panel-heading">
					</div>
					<div class = "panel-body">
						<div class = "form-group">
							<label for = "Last_Name">Last Name: </label>
							<input class = "form-control" name = "Last_Name" type = "text" required = "required">
						</div>
						<div class = "form-group">	
							<label for = "First_Name">First Name: </label>
							<input class = "form-control" name = "First_Name" maxlength = "12" type = "text" required = "required">
						</div>
						<div class = "form-group">
							<label for = "Middle_Name">Middle Name: </label>
							<input class = "form-control" type = "text" name = "Middle_Name" required = "required">
						</div>
						<div class = "form-group">
							<label for = "Position_">Position: </label>
							<input class = "form-control" type = "text" name = "Position_" required = "required">
						</div>
						<div class = "form-group">
							<label for = "Office_">Office: </label>
							<input class = "form-control" type = "text" name = "Office_" required = "required">
						</div>
						<div class = "form-group">
							<label for = "Contact_No">Contact No.: </label>
							<input class = "form-control" type = "text" name = "Contact_No">
						</div>
                        <div class = "form-group">
							<label for = "Email_Ad">Email Address.: </label>
							<input class = "form-control" type = "text" name = "Email_Ad">
						</div>


						  <div class="form-group col-md-6">
                                                    <label for="Picture" class="col-form-label">Profile Picture</label>
                                                    <input required="required"  type="file" name="Picture_" class="btn btn-success form-control"  id="inputCity">
                                                </div>
							<button  class = "btn btn-primary" name = "add_employee" ><span class = "glyphicon glyphicon-save"></span> SAVE</button>
							<br />
					</div>
					<?php require 'add_employee.php' ?>					
					</div>
				</form>
			</div>	
		</div>	
		<div class = "panel panel-primary">
			<div class = "panel-heading">
				<label>ACCOUNTS / ADMINISTRATOR</Label>
			</div>
			<div class = "panel-body">
				<button id = "show" class = "btn btn-info"><span class  = "glyphicon glyphicon-plus"></span> ADD</button>
				<br />
				<br />		
				<table id = "table" class = "display" cellspacing = "0"  >
					<thead>
						<tr>
							<th>Emp ID</th>
							<th>Name</th>
							<th>Position</th>
							<th><center>Action</center></th>
						</tr>
					</thead>
					<tbody>
					<?php
						$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
						$query = $conn->query("SELECT * FROM `employees_` ORDER BY `Emp_ID` DESC") or die(mysqli_error());
						while($fetch = $query->fetch_array()){
					?>
						<tr>
							<td><?php echo $fetch['Emp_ID']?></td>
							<td><?php echo $fetch['Last_Name']." ".$fetch['First_Name']." ".$fetch['Middle_Name']?></td>
                            <td><?php echo $fetch['Position_']?></td>
                            <td><center><a class = "btn btn-sm btn-warning" href = "edit_employee.php?id=<?php echo $fetch['Emp_ID']?>&Last_Name=<?php echo $fetch['First_Name']?>"><i class = "glyphicon glyphicon-edit"></i>Update</a> <a onclick="confirmationDelete(this);return false;" href = "delete_employee.php?id=<?php echo $fetch['Emp_ID']?>" class = "btn btn-sm btn-danger"><i class = "glyphicon glyphicon-remove"></i> Delete</a></center></td>
						</tr>
					<?php
						}
						$conn->close();
					?>
					</tbody>
				</table>
			</div>
		</div>
		
	</div>
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright Health Center Patient Record Management System 2015</label>
	</div>
	
<?php require'script.php' ?>
<script type = "text/javascript">
	function confirmationDelete(anchor)
		{
			var conf = confirm('Are you sure want to delete this record?');
			if(conf)
			window.location=anchor.attr("href");
		}
</script>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>	
</body>
</html>