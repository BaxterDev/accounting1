<!DOCTYPE html>
<?php
	require_once 'logincheck.php';
?>
<html lang = "eng">
	<head>
		<title>Receivables Management System Version 1.0</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "../images/logo.png" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "../images/logo.png" style = "float:left;" height = "55px" /><label class = "navbar-brand">Receivables Management System - Maconacon, Isabela</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `user_ca` WHERE `Series_` = '$_SESSION[Series_]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['First_Name']." ".$f['Last_Name'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
	<div id = "sidebar">
			<ul id = "menu" class = "nav menu">
				<li><a href = "User_Home.php"><i class = "glyphicon glyphicon-home"></i> Dashboard</a></li>
				<li><a href = "admin.php"><i class = "glyphicon glyphicon-home"></i> Cash Advance</a></li>
				<li><a href = "Liquidation.php"><i class = "glyphicon glyphicon-home"></i> Liquidation</a></li>
				
				<li><a href = ""><i class = "glyphicon glyphicon-cog"></i> Reports</a>
					<ul>
						<li><a href = "Cash_Advance.php"><i class = "glyphicon glyphicon-folder-open"></i> Pending</a></li>
						<li><a href = "Cash_Ad_Approved_View.php"><i class = "glyphicon glyphicon-folder-open"></i> Approved</a></li>
						<li><a href = "Cash_Ad_CP_View.php"><i class = "glyphicon glyphicon-folder-open"></i> Check Preparation</a></li>
					</ul>
				</li>
	</div>
	<div id = "content">
		<br />
		<br />
		<br />
		<div class = "panel panel-success">	
		<?php
			$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
			$query = $conn->query("SELECT * FROM `cash_Advance` WHERE `Trans_No` = '$_GET[Trans_No]'") or die(mysqli_error());
			$fetch = $query->fetch_array();
		?>
			<div class = "panel-heading">
				<label>APPROVAL OF CASH ADVANCE</label>
				<a href = "Liquidation.php" class = "btn btn-sm btn-info" style = "float:right; margin-top:-5px;"><span class = "glyphicon glyphicon-hand-right"></span> BACK</a>
			</div>
			<div class = "panel-body">
				<form id = "form_admin" method = "POST" enctype = "multi-part/form-data" >
					<div class = "panel panel-default" style = "width:60%; margin:auto;">
					<div class = "panel-heading">
					</div>
					<div class = "panel-body">
						<div class = "form-group">
							<label for = "Trans_No">Transaction Number: </label>
							<input class = "form-control" name = "Trans_No" value = "<?php echo $fetch['Trans_No'] ?>" type = "text" required = "required">
						</div>
						<div class = "form-group">	
							<label for = "Trans_ID">Transaction ID: </label>
							<input class = "form-control" name = "Trans_ID" value = "<?php echo $fetch['Trans_ID']?>" maxlength = "12" type = "text" required = "required">
						</div>
						<div class = "form-group">
							<label for = "firstname">First Name: </label>
							<input class = "form-control" type = "text" name = "First_Name" value = "<?php echo $fetch['First_Name'] ?>" required = "required">
						</div>
						<div class = "form-group">
							<label for = "middlename">Middlename: </label>
							<input class = "form-control" type = "text" name = "Middle_Name" value = "<?php echo $fetch['Middle_Name'] ?>">
						</div>
						<div class = "form-group">
							<label for = "lastname">Lastname: </label>
							<input class = "form-control" type = "text" name = "Last_Name" value = "<?php echo $fetch['Last_Name'] ?>">
						</div>
						<div class = "form-group">
							<label for = "Purpose">Purpose_: </label>
							<input class = "form-control" type = "text" name = "Purpose_" value = "<?php echo $fetch['Purpose_'] ?>">
						</div>
						<div class = "form-group">
							<label for = "Destination">Destination_: </label>
							<input class = "form-control" type = "text" name = "Destination_" value = "<?php echo $fetch['Destination_'] ?>">
						</div>
						<div class = "form-group">
							<label for = "Amount">Cash Advance: </label>
							<input class = "form-control" type = "text" name = "Amount_" value = "<?php echo $fetch['Amount_'] ?>">
						</div>
                        <div class = "form-group">
							<label for = "Liquidation">Liquidation: </label>
							<input class = "form-control" type = "text" name = "Liquidation_" value = "<?php echo $fetch['Liquidation_'] ?>">
						</div>
						<div class = "form-group">
							<label for = "Balance_">Balance: </label>
							<input class = "form-control" type = "text" name = "Balance_" value = "<?php echo $fetch['Balance_'] ?>">
						</div>


						<div class = "form-group">
							<label for = "Status">Status: </label>
							<input class = "form-control" type = "text" name = "Status_" value = "<?php echo $fetch['Status_'] ?>">
						
                        
                            <select class="form-control" name="currency_selling" required >
         <option value=""></option>
         <option value="Unliquidated">Unliquidated</option>
      <option value="Refund">Refund</option>
      <option value="Reimbursement">Reimbursement</option>
      <option value="Liquidated">Liquidated</option>
      </select>
                        </div>
							<button  class = "btn btn-warning" name = "Settle_" ><span class = "glyphicon glyphicon-edit"></span> Liquidate</button>
							<br />
					</div>
					<?php require 'edit_CA_approval.php' ?>					
					</div>
				</form>
			</div>	
		</div>	
	</div>
	<div id = "footer">
		<label class = "footer-title">&copy; Receivables Management System Version 1.0</label>
	</div>
<?php require'script.php' ?>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>	
</body>
</html>