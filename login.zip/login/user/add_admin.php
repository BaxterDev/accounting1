<?php
if (isset($_POST['add_admin'])) {
    // Retrieve and sanitize user input
    $Trans_ID = $_POST['Trans_ID'];
    $Trans_Date = $_POST['Trans_Date'];
    $Emp_ID = $_POST['Emp_ID'];
    $Last_Name = $_POST['Last_Name'];
    $First_Name = $_POST['First_Name'];
    $Middle_Name = $_POST['Middle_Name'];
    $Purpose_ = $_POST['Purpose_'];
    $Destination_ = $_POST['Destination_'];
    $Departure_Date = $_POST['Departure_Date'];
    $Arrival_Date = $_POST['Arrival_Date'];
    $Amount_ = $_POST['Amount_'];
    $Status_ = $_POST['Status_'];
   

    // Create a connection to the database
    $conn = new mysqli("localhost", "root", "", "receivables_system");

    // Check for a connection error
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    // Prepare a statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM `user_` WHERE `User_Name` = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters and execute the statement
    $stmt->bind_param("s", $Trans_ID);
    $stmt->execute();
    $result = $stmt->get_result();
    $c1 = $result->num_rows;

    if ($c1 > 0) {
        echo "<script>alert('Username already taken');</script>";
    } else {
        // Prepare an INSERT statement
        $stmt = $conn->prepare("INSERT INTO `cash_advance` (`Trans_ID`, `Trans_Date`, `Emp_ID`, `Last_Name`, `First_Name`, `Middle_Name`, `Purpose_`, `Destination_`, `Departure_Date`, `Arrival_Date`, `Amount_`, `Status_`) Values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        // Bind parameters and execute the INSERT statement
        $stmt->bind_param("ssssssssssss", $Trans_ID, $Trans_Date, $Emp_ID, $Last_Name, $First_Name, $Middle_Name, $Purpose_, $Destination_, $Departure_Date, $Arrival_Date, $Amount_, $Status_);
        $stmt->execute();

        echo "<script>location.replace('admin.php');</script>";
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}
?>