<!DOCTYPE html>
<?php
	require_once 'logincheck.php';
?>
<html lang = "eng">
	<head>
		<title>Barangay Fely Health Station Records System</title>
		<meta charset = "utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "../images/logo.png" />
		<link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "../css/customize.css" />
	</head>
<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "../images/Logo.jpg" style = "float:left;" height = "55px" /><label class = "navbar-brand">Barangay Fely Health Center Records Management System</label>
			<?php
				$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
				$q = $conn->query("SELECT * FROM `user_ca` WHERE `Series_` = '$_SESSION[Series_]'") or die(mysqli_error());
				$f = $q->fetch_array();
			?>
			<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php
							echo $f['First_Name']." ".$f['Last_Name'];
							$conn->close();
						?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><i class = "glyphicon glyphicon-log-out"></i> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
	<div id = "sidebar">
			<ul id = "menu" class = "nav menu">
				<li><a href = "User_Home.php"><i class = "glyphicon glyphicon-home"></i> Dashboard</a></li>
				<li><a href = "admin.php"><i class = "glyphicon glyphicon-home"></i> Cash Advance</a></li>
				<li><a href = "Liquidation.php"><i class = "glyphicon glyphicon-home"></i> Liquidation</a></li>
				
				<li><a href = ""><i class = "glyphicon glyphicon-cog"></i> Reports</a>
					<ul>
						<li><a href = "Cash_Advance.php"><i class = "glyphicon glyphicon-folder-open"></i> Pending</a></li>
						<li><a href = "Cash_Ad_Approved_View.php"><i class = "glyphicon glyphicon-folder-open"></i> Approved</a></li>
						<li><a href = "Cash_Ad_CP_View.php"><i class = "glyphicon glyphicon-folder-open"></i> Check Preparation</a></li>
						<li><a href = "Unliquidated_User_View.php"><i class = "glyphicon glyphicon-folder-open"></i> Unliquidated</a></li>
					</ul>
				</li>
	</div>
	<div id = "content">
		<br />
		<br />
		<br />
		<div id = "add" class = "panel panel-success">	
			<div class = "panel-heading">
				<label>ADD ADMINISTRATOR</label>
				<button id = "hide" class = "btn btn-sm btn-danger" style = "float:right; margin-top:-5px;"><span class = "glyphicon glyphicon-remove"></span> CLOSE</button>
			</div>
			<div class = "panel-body">
				<form id = "form_admin" method = "POST" enctype = "multi-part/form-data" >
					<div class = "panel panel-default" style = "width:60%; margin:auto;">
					<div class = "panel-heading">
					</div>
					<div class = "panel-body">
						<div class = "form-group">
							<label for = "username">Username: </label>
							<input class = "form-control" name = "User_Name" type = "text" required = "required">
						</div>
						<div class = "form-group">	
							<label for = "password">Password: </label>
							<input class = "form-control" name = "Password" maxlength = "12" type = "password" required = "required">
						</div>
						<div class = "form-group">
							<label for = "firstname">Firstname: </label>
							<input class = "form-control" type = "text" name = "First_Name" required = "required">
						</div>
						<div class = "form-group">
							<label for = "middlename">Middlename: </label>
							<input class = "form-control" type = "text" placeholder = "(Optional)" name = "Middle_Name">
						</div>
						<div class = "form-group">
							<label for = "lastname">Lastname: </label>
							<input class = "form-control" type = "text" name = "Last_Name">
						</div>
							<button  class = "btn btn-primary" name = "save_admin" ><span class = "glyphicon glyphicon-save"></span> SAVE</button>
							<br />
					</div>
					<?php require 'add_admin.php' ?>					
					</div>
				</form>
			</div>	
		</div>	
		<div class = "panel panel-primary">
			<div class = "panel-heading">
				<label>ACCOUNTS / ADMINISTRATOR</Label>
			</div>
			<div class = "panel-body">
				
				<br />
				<br />		
				<table id = "table" class = "display" cellspacing = "0"  >
					<thead>
						<tr>
							<th>Emp ID</th>
							<th>Name</th>
							<th>Position</th>
							<th><center>Action</center></th>
						</tr>
					</thead>
					<tbody>
					<?php
						$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
						$query = $conn->query("SELECT * FROM `employees_` ORDER BY `Emp_ID` DESC") or die(mysqli_error());
						while($fetch = $query->fetch_array()){
					?>
						<tr>
							<td><?php echo $fetch['Emp_ID']?></td>
							
							<td><?php echo $fetch['First_Name']." ".$fetch['Last_Name']?></td>
							<td><?php echo $fetch['Position_']?></td>
							<td><center><a class = "btn b	tn-sm btn-warning" href = "edit_admin.php?id=<?php echo $fetch['Emp_ID']?>&Last_Name=<?php echo $fetch['Last_Name']?>"><i class = "glyphicon glyphicon-edit"></i>Cash Advance</a></center></td>
						</tr>
					<?php
						}
						$conn->close();
					?>
					</tbody>
				</table>
			</div>
		</div>
		
	</div>
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright Health Center Patient Record Management System 2015</label>
	</div>
	
<?php require'script.php' ?>
<script type = "text/javascript">
	function confirmationDelete(anchor)
		{
			var conf = confirm('Are you sure want to delete this record?');
			if(conf)
			window.location=anchor.attr("href");
		}
</script>
<script type = "text/javascript">
    $(document).ready(function() {
        function disableBack() { window.history.forward() }

        window.onload = disableBack();
        window.onpageshow = function(evt) { if (evt.persisted) disableBack() }
    });
</script>	
</body>
</html>