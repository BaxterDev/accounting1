<?php
	$Trans_No = $_GET['Trans_No'];
	if(ISSET($_POST['Approve_'])){
		$Status_ = $_POST['Status_'];
		$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
		$conn->query("UPDATE `cash_advance` SET `Status_` = '$Status_' WHERE `Trans_No` = '$Trans_No'") or die(mysqli_error());
		echo("<script> location.replace('Cash_Ad_Approved.php');</script>");
	}
	if(ISSET($_POST['edit_admin'])){
			$User_Name = $_POST['User_Name'];
			$Password = $_POST['Password'];
			$First_Name = $_POST['First_Name'];
			$Middle_Name = $_POST['Middle_Name'];
			$Last_Name = $_POST['Last_Name'];
			$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
			$conn->query("UPDATE `user_` SET `User_Name` = '$User_Name', `Password` = '$Password', `First_Name` = '$First_Name', `Middle_Name` = '$Middle_Name', `Last_Name` = '$Last_Name' WHERE `Series_` = '$id'") or die(mysqli_error());
			echo("<script> location.replace(' admin.php');</script>");
		}
	if(ISSET($_POST['edit_user'])){
			$username = $_POST['username'];
			$password = $_POST['password'];
			$firstname = $_POST['firstname'];
			$middlename = $_POST['middlename'];
			$lastname = $_POST['lastname'];
			$section = $_POST['section'];
			$conn = new mysqli("localhost", "root", "", "hcpms") or die(mysqli_error());
			$conn->query("UPDATE `user` SET `username` = '$username', `password` = '$password', `firstname` = '$firstname', `middlename` = '$middlename', `lastname` = '$lastname', `section` = '$section' WHERE `user_id` = '$id'") or die(mysqli_error());
			echo("<script> location.replace(' user.php');</script>");
		}	
