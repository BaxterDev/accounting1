<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Receivables Management System - Version 1.0">
    <meta name="robots" content="noindex, nofollow">
    <meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:;">
    <title>Receivables Management System - Version 1.0</title>
    <link rel="shortcut icon" href="images/logo.png">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
    <link rel="stylesheet" type="text/css" href="css/customize.css" />
</head>
<body>
    <div class="navbar navbar-default navtop">
       
<label class="navbar-brand">OFFICE OF THE MUNICIPAL ACCOUNTANT - MACONACON, ISABELA</label>
    </div>
    <div id="sidelogin">
	
        <form action="login.php" enctype="multipart/form-data" method="POST">
            <label class="lbllogin">User Authentication</label>
            <br />
            <div class="form-group">
                <label for="User_Name">Username</label>
                <input class="form-control" type="text" name="User_Name" id="User_Name" required="required" autocomplete="off" />
            </div>
            <br />
            <div class="form-group">
                <label for="Password">Password</label>
                <input class="form-control" type="password" name="Password" id="Password" required="required" autocomplete="off" />
            </div>
            <br />
            <div class="form-group">
                <button class="btn btn-success form-control" type="submit" name="login"><span class="glyphicon glyphicon-log-in"></span> Login</button>
            </div>
        </form>
    </div>
    <img src="images/maconacon2.webp" class="background">
    <div id="footer">
        <label class="footer-title">&copy; Copyright Accounting System Version 1.0</label>
    </div>
</body>
</html>