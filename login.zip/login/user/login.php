<?php
	session_start();
	if(ISSET($_POST['login'])){
		$User_Name = $_POST['User_Name'];
		$Password = $_POST['Password'];
		$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
		$query = $conn->query("SELECT * FROM `user_ca` WHERE `User_Name` = '$User_Name' && `Password` = '$Password'");
		$fetch = $query->fetch_array();
		$valid = $query->num_rows;
		$Section_ = $fetch['Section_'];	
			if($valid > 0){
				
			}
			
			if($Section_ == "Cash Advance"){
				$_SESSION['Series_'] = $fetch['Series_'];
				echo("<script> location.replace('User_Home.php');</script>");
			}	
	}
		if($Section_ == "Approver"){
			$_SESSION['Series_'] = $fetch['Series_'];
			echo("<script> location.replace('CA_Approver.php');</script>");
		}
	
	if($Section_ == "Payment"){
		$_SESSION['Series_'] = $fetch['Series_'];
		echo("<script> location.replace('Home_Pay.php');</script>");
	}

	
			else{
				echo "<script>alert('Account Does Not Exist!')</script>";
				echo "<script>window.location = 'index.php'</script>";
			}				
	
		$conn->close();
	