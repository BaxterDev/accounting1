<?php
	session_start();
		if(!ISSET($_SESSION['Series_']))
			{
				header('location:User_Home.php');
			}
?>