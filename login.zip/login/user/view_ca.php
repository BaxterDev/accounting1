<!DOCTYPE html>
<?php
	require_once'logincheck.php';
	$conn = new mysqli("localhost", "root", "", "receivables_system") or die(mysqli_error());
	$query = $conn->query("SELECT * FROM `user_ca` WHERE `Series_` = '$_SESSION[Series_]'") or die(mysqli_error());
	$fetch = $query->fetch_array();
?>
<html lang = "en">
	<head>	
		<title>Health Center Patient Record Management System</title>
		<meta charset = "UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "images/logo.png" />
		<link rel = "stylesheet" type = "text/css" href = "css/bootstrap.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/jquery.dataTables.css" />
		<link rel = "stylesheet" type = "text/css" href = "css/customize.css" />
	</head>
	<body>
	<div class = "navbar navbar-default navbar-fixed-top">
		<img src = "images/logo.png" style = "float:left;" height = "55px" /><label class = "navbar-brand">Receivables Management System - LGU Maconacon 2024</label>
		<ul class = "nav navbar-right">	
				<li class = "dropdown">
					<a class = "user dropdown-toggle" data-toggle = "dropdown" href = "#">
						<span class = "glyphicon glyphicon-user"></span>
						<?php echo $fetch['First_Name']." ".$fetch['Last_Name'] ?>
						<b class = "caret"></b>
					</a>
				<ul class = "dropdown-menu">
					<li>
						<a class = "me" href = "logout.php"><span class = "glyphicon glyphicon-log-out"></span> Logout</a>
					</li>
				</ul>
				</li>
			</ul>
	</div>
	<br />
	<br />
	<br />
	<div class = "well">
		<div class = "panel panel-warning">
			<div class = "panel-heading">
				<center><label>Cash Advances Summary</label></center>
			</div>
		</div>
		<div class = "panel panel-success">	
			<div class = "panel-heading">
			<?php
				$q = $conn->query("SELECT * FROM `cash_advance` WHERE `Trans_No` = '$_GET[Trans_No]'") or die(mysqli_error());
				$f = $q->fetch_array();
			
			?>
				<label>Employee Information: </label class = "text-warning"><?php echo $f['First_Name']." ".substr($f['Middle_Name'], 0,1).". ".$f['Last_Name']?></label></label>
				<a href = "ca_print.php" id = "d_record" style = "float:right; margin-right:10px;" href = "" class = "btn btn-success"><span class = "glyphicon glyphicon-print"></span> Print</a>
		<a href = "Cash_Advance.php" id = "d_record" style = "float:right; margin-right:10px;" href = "" class = "btn btn-success"><span class = "glyphicon glyphicon-book"></span> Refresh</a>
				<label style = "margin-top:5px; margin-right:5px; float:right;">ITR No: <label class = "text-warning"><?php echo $f['Trans_No']?></label></label>
			</div>
			<div class = "panel-body">
					<div style = "float:left; width:10%;">
						<label style = "font-size:15px;">Trans. No</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Trans_No']?></label>
					</div>
					<div style = "float:left; width:10%;">
						<label style = "font-size:15px;">Trans. ID</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Trans_Date']?></label>
					</div>
					<div style = "float:left; width:15%;">
						<label style = "font-size:15px;">Voucher No.</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Voucher_No']?></label>
					</div>
					<div style = "float:left; width:15%;">
						<label style = "font-size:15px;">Emp ID</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Emp_ID']?></label>
					</div>
					<div style = "float:left; width:10%;">	
						<label style = "font-size:15px;" for = "Last Name">Last Name</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Last_Name']?></label>
					</div>
					<div style = "float:left; width:10%;">	
						<label style = "font-size:15px;" for = "Middle Name">Middle Name</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Middle_Name']?></label>
					</div>
					<div style = "float:left; width:15%;">
						<label for = "family_no" style = "font-size:15px;">First Name</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['First_Name']?></label>
					</div>	
					<br style = "clear:both;" />
					<hr style = "border:1px dotted #d3d3d3;"/>
					<div>
						<label style = "font-size:15px;">Purpose</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Purpose_']?></label>
					</div>
					<hr style = "border:1px dotted #d3d3d3;"/>
					<div class = "form-group" style = "width:15%; float:left;">
						<label style = "font-size:15px;" for = "bp">Destination</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Destination_']?></label>
					</div>
					<br style = "clear:both;" />
					<hr style = "border:1px dotted #d3d3d3;"/>
					<br />

					<div style = "float:left; width:15%;">
						<label style = "font-size:15px;">Departure Date</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Departure_Date']?></label>
					</div>
					<div style = "float:left; width:10%;">
						<label style = "font-size:15px;">Arrival Date</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Arrival_Date']?></label>
					</div>
					<div style = "float:left; width:15%;">
						<label style = "font-size:15px;">Check No.</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Check_No']?></label>
					</div>
					<div style = "float:left; width:15%;">
						<label style = "font-size:15px;">Check Date</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Check_Date']?></label>
					</div>
					<div style = "float:left; width:15%;">	
						<label style = "font-size:15px;" for = "Amount">Cash Advance</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Amount_']?></label>
					</div>
					<div style = "float:left; width:15%;">	
						<label style = "font-size:15px;" for = "Status_">Status</label>
						<br />
						<label style = "font-size:15px;" class = "text-muted"><?php echo $f['Status_']?></label>
					</div>
					
					<br style = "clear:both;" />
					<hr style = "border:1px dotted #d3d3d3;"/>
			</div>	
		</div>	
		 
	</div>
	<div id = "footer">
		<label class = "footer-title">&copy; Copyright: Receivables Management System - LGU Maconacon 2024</label>
	</div>
	</body>
		<?php require "script.php" ?>
</html>