
<style>
    #uni_modal .modal-footer{
        display:none !important;
    }
</style>
<div class="container-fluid">
    <div id="outprint_modal">
        <p>
        
        </p>
        <p><span class="ms-5"></span>To certify further, that he/she has no derogatory and/or criminal records filed in this barangay.</p>
        
        <br>
        <br>
        <br>
        <br>
        <div class="d-flex w-100 justify-content-end">
          
            
            <div class="col-4">
                <div class="w-100 text-center border-bottom border-dark"><?php echo isset($official) ? $official : '' ?></div>
             
            </div>

        </div>
        
        <br>
        <br>
        <dl class="row">
            <dt class='col-auto'>OR #:</dt>
          
        </dl>
        <dl class="row">
            <dt class='col-auto'>Data Issued:</dt>
         
        </dl>
    </div>
    <div class="row justify-content-end border-top pt-2">
        <div class="col-auto me-1">
            <button class="btn btn-sm btn-success rounded-0" id='print_data' type="button"><i class="fa fa-print"></i> Print</button>
        </div>
        <div class="col-auto">
            <button class="btn btn-sm btn-dark rounded-0" data-bs-dismiss='modal' type="button"><i class="fa fa-times"></i> Close</button>
        </div>
    </div>    
    <div class="clearfix mb-1"></div>
</div>
<div id="noscript2" class="d-none">
    <div class="d-flex w-100 align-items-center">
        <div class="col-2 px-3">
            <center><img src="<?php echo is_file('./../uploads/logo.png') ? './../uploads/logo.png' : './../images/no-image-available.png' ?>" alt="Barangay Logo" class="img-fluid rounded-0" width="100px" height="100px"></center>
        </div>
        <div class="col-8 flex-grow-1 lh-1">
            <p class="m-0 text-center">Republic of the Philippines</p>
           
            <div class="clearfix"></div>
         
        </div>
        <div class="col-2">

        </div>
    </div>
    <hr>
    <br>
    <h2 class="fw-bold text-center">Individual Barangay Clearance</h2>
    <br>
    <br>
    <br>
    <br>
</div>
<script>
$(function(){
    $('#print_data').click(function(){
        var _p = $('#outprint_modal').clone()
        var _h = $('head').clone()
        var _header = $('#noscript2').html()
        var el = $('<div>')
        el.append(_h)
        el.append(_header)
        el.append(_p)
        
        var nw = window.open("","_blank","width=1000,height=900,top=50,left=250")
                    nw.document.write(el.html())
                    nw.document.close()
                    setTimeout(() => {
                    nw.print()
                        setTimeout(() => {
                            nw.close()
                        }, 200);
                    }, 500);
    })
})
</script>